# Plotting code for Figures 3 to 5 of BMC Microbiology article
# "A semi-automated workflow for biofilm assays"
# Katrin Leinweber (2016-Jan-17)

rm(list = ls())
library(ggplot2) # learn more at http://docs.ggplot2.org/current/
library(scales) # percent_format; learned from https://stackoverflow.com/questions/3695497/


# Figure 3 - Tecan-vs-Ultrospec

df_TvU <- read.csv2("Additional File 7a - Figure 3 - Tecan-vs-Ultrospec.csv")
df_TvU$Photometer <- factor(df_TvU$Photometer,
                               levels = c("plate reader", "EtOH & photometer"))
# sort factors to facet logically, see http://docs.ggplot2.org/current/facet_grid.html

p_TvU <- ggplot(data = df_TvU,
                mapping = aes(x = Achmi,
                              y = Abs_580))

p_TvU +
  geom_boxplot(notch = T, varwidth = T) +
  scale_y_continuous(limits = c(0, 1),
                     breaks = seq(from = 0, to = 1, by = 0.2)) +
  facet_grid(. ~ Photometer) +
  labs(x = "Cell culture",
       y = "Absorbance at 580 nm\n") +
  theme_classic(base_size = 14)

ggsave("../figures/Tecan-vs-Ultrospec.pdf", height = 5, width = 5)


# Figure 4 - Tecan-wavelengths

df_TW <- read.csv2("Additional File 7b - Figure 4 - Tecan-wavelengths.csv")
df_TW$nm_wavelength <- factor(df_TW$nm_wavelength,
                               levels = c("630 nm", "650 nm", "750 nm", "580 nm (CV stain)"))

p_TW <- ggplot(data = df_TW,
                  mapping = aes(x = Achmi,
                                y = Abs))

p_TW +
  geom_boxplot(notch = T, varwidth = T) +
  scale_y_continuous(limits = c(0, 0.4),
                     breaks = seq(from = 0, to = 0.4, by = 0.1)) +
  facet_grid(. ~ nm_wavelength) +
  labs(x = "Cell culture",
       y = "Absorbance at wavelength\n") +
  theme_classic(base_size = 18)

ggsave("../figures/Figure 4 - Tecan-wavelengths.pdf", height = 5, width = 10)


# Figure 5 - Tecan-wavelengths-SN

df_TWS <- read.csv2("Additional File 7c - Figure 5 - Tecan-wavelengths-SN.csv")
df_TWS$nm_wavelength <- factor(df_TWS$nm_wavelength,
                       levels = c("630 nm", "650 nm", "750 nm", "580 nm (CV stain)"))

p_TWS <- ggplot(data = df_TWS,
                mapping = aes(x = fraction_SN,
                                      y = Abs))

p_TWS +
  geom_point(size = 3, alpha = 0.5) +
  geom_line(linetype = "dotted") +
  scale_x_continuous(labels = percent_format()) +
  scale_y_continuous(limits = c(0, 0.2),
                     breaks = seq(from = 0, to = 0.2, by = 0.05)) +
  facet_grid(. ~ nm_wavelength) +
  labs(x = "Fraction of spent bacterial supernatant in fresh BM" ,
       y = "Absorbance at wavelengths\n") +
  theme_classic(base_size = 18)

ggsave("../figures/Figure 5 - Tecan-wavelengths-SN.pdf", height = 5, width = 10)
